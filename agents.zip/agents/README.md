# Multi Agent

(C) UPM - DynReact EU-RFCS program

Version 2.0.0:

* Borwser agent becomes functional to keep tracking on the live coils
* Launcher is able to query and Update settings for coils
* Coil auction logic was extended
* General accomodation of agents were carried out.
