#! /bin/bash
scp *.py jb@apiict00.etsii.upm.es:/home/jb/soft/dynreact/
scp *.py jb@apiict03.etsii.upm.es:/home/jb/soft/dynreact/
scp *.py jb@pcudp03.etsii.upm.es:/home/jb/agents_jb03/
scp *.py jb@pcudp03.etsii.upm.es:/home/jb/agents_jb00/

