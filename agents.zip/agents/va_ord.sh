nohup python3 va.py -an 8 -sd 0.25 -lag log@apiict00.etsii.upm.es -bag browser@apiict00.etsii.upm.es -u va08@apiict00.etsii.upm.es -p DynReact &
nohup python3 va.py -an 9 -sd 0.25 -lag log@apiict00.etsii.upm.es -bag browser@apiict00.etsii.upm.es -u va09@apiict00.etsii.upm.es -p DynReact &
nohup python3 va.py -an 10 -sd 0.25 -lag log@apiict00.etsii.upm.es -bag browser@apiict00.etsii.upm.es -u va10@apiict00.etsii.upm.es -p DynReact &
nohup python3 va.py -an 11 -sd 0.25 -lag log@apiict00.etsii.upm.es -bag browser@apiict00.etsii.upm.es -u va11@apiict00.etsii.upm.es -p DynReact &
nohup python3 va.py -an 12 -sd 0.25 -lag log@apiict00.etsii.upm.es -bag browser@apiict00.etsii.upm.es -u va12@apiict00.etsii.upm.es -p DynReact &
